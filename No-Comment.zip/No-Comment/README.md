# No-Comment

No-Comment is a Millennium plugin for Steam that injects LuaTools UI and backend workflows into the Steam client.

It combines a Python backend (`backend/`) with injected frontend scripts (`public/`) to support app add/remove flows, DLC/content helpers, fixes workflow, and in-client settings/localization.

## Features

- Add games via LuaTools from Steam store pages.
- Bundle-aware add flow (filters to valid base games).
- DLC/content manager for related app entries.
- Remove LuaTools content for an app.
- Native-looking "In Library" indicators on relevant store surfaces.
- Game fix workflow (check, apply, cancel, unfix).
- Installed Lua/fix management UI.
- Localization support with locale validation tooling.
- Auto-update checks and restart hooks.

## Requirements

- Windows + Steam.
- Millennium installed and active.
- Python 3.x available on `PATH`.
- Python packages from `requirements.txt`:
  - `requests`
  - `httpx==0.27.2`

Install dependencies:

```powershell
pip install -r requirements.txt
```

## Quick Start

1. Clone this repo.
2. Build the frontend bundle:

```powershell
python scripts/build_frontend.py
```

3. Deploy to Steam plugins:

```powershell
.\deploy.ps1
```

By default, deployment copies this repo into:

- `C:\Program Files (x86)\Steam\plugins\<current-folder-name>`

and restarts Steam.

## Development Workflow

### Frontend

- Edit source files in `public/src/luatools/`.
- Do not hand-edit `public/modules/luatools.app.js` (generated).
- Rebuild after edits:

```powershell
python scripts/build_frontend.py
```

### Locales

Validate/fill missing locale keys against `en`:

```powershell
python scripts/validate_locales.py
```

### Deploy

Default deploy (build + copy + restart Steam):

```powershell
.\deploy.ps1
```

Deploy without restarting Steam:

```powershell
.\deploy.ps1 -NoRestart
```

Deploy to a custom plugins directory:

```powershell
.\deploy.ps1 -PluginsDir "D:\Steam\plugins"
```

## Repository Layout

```text
backend/                 Python backend methods exposed to Millennium
backend/data/            Runtime JSON/text state (settings, limits, update info)
backend/locales/         Locale JSON files
backend/settings/        Settings schema + manager
public/                  Injected web assets and bootstrap script
public/src/luatools/     Editable frontend modules (source of truth)
public/modules/          Built frontend bundle output
scripts/                 Utility scripts (build frontend, validate locales)
plugin.json              Millennium plugin manifest
deploy.ps1               Windows deployment script
```

## Runtime Notes

- Settings persist in `backend/data/settings.json`.
- Daily add usage persists in `backend/data/daily_add_limit.json`.
- Update source is configured in `backend/data/update.json`.
- Frontend assets are copied into Steam UI plugin assets on load/deploy.

## Troubleshooting

- If UI changes do not appear, rebuild and deploy again.
- If deployment fails, verify `C:\Program Files (x86)\Steam\plugins` exists.
- If Python dependency errors appear, rerun `pip install -r requirements.txt`.
- If locale/UI text looks wrong, run `python scripts/validate_locales.py`.
